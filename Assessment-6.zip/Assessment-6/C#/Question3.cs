﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_6
{
    internal class Question3
    {
        static void Main(string[] args)
        {
            
            int[] numbers = { 5, 10, 15, 20, 25 };

            int sum = 0;
            foreach (int number in numbers)
            {
                sum += number;
            }
            double average = (double)sum / numbers.Length;
            int max = numbers[0];
            int min = numbers[0];
            foreach (int number in numbers)
            {
                if (number > max)
                {
                    max = number;
                }
                if (number < min)
                {
                    min = number;
                }
            }
            Console.WriteLine($"Sum: {sum}");
            Console.WriteLine($"Average: {average}");
            Console.WriteLine($"Maximum Value: {max}");
            Console.WriteLine($"Minimum Value: {min}");
        }
    }
}

