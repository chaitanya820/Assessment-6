﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_6
{
    internal class Question5
    
    {
        static void Main(string[] args)
        {
            int numberOfLines = 5;

            for (int lineNumber = 1; lineNumber <= numberOfLines; lineNumber++)
            {
                for (int number = 1; number <= lineNumber; number++)
                {
                    Console.Write(number + " "); 
                }
                Console.WriteLine();
            }
        }
    }

}

