﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_6
{
    internal class Question6
    {
        class Student
        {
            public int Id { get; set; }
            public string Name { get; set; }
        }

        class Enrollment
        {
            public int StudentId { get; set; }
            public string Course { get; set; }
        }

        class Program
        {
            static void Main()
            {
                
                List<Student> students = new List<Student>
        {
            new Student { Id = 1, Name = "Alice" },
            new Student { Id = 2, Name = "Bob" }
        };

                List<Enrollment> enrollments = new List<Enrollment>
        {
            new Enrollment { StudentId = 1, Course = "Mathematics" },
            new Enrollment { StudentId = 2, Course = "Physics" },
            new Enrollment { StudentId = 1, Course = "Chemistry" } 
        };
                var result = from s in students
                             join e in enrollments on s.Id equals e.StudentId
                             select new { Student = s.Name, Courses = e.Course };
                foreach (var item in result)
                {
                    Console.WriteLine($"{item.Student} is enrolled in {item.Courses}");
                }
            }
        }
    }
}
    






