﻿namespace Assessment_6
{
    class Question2

    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Num Guessing Game!");
            Console.Write("Enter the range (e.g., min max): ");
            string[] range = Console.ReadLine().Split(' ');
            int min = Int32.Parse(range[0]);
            int max = Int32.Parse(range[1]);

            Random random = new Random();
            int randomNumber = random.Next(min, max + 1);
            int attempts = 0;
            bool win = false;

            do
            {
                Console.Write($"Guess the num ({min} - {max}): ");
                string input = Console.ReadLine();
                int guess = Int32.Parse(input);

                attempts++;

                if (guess == randomNumber)
                {
                    win = true;
                    break;
                }
                else if (guess < randomNumber)
                {
                    Console.WriteLine("Too low! Try again.");
                }
                else
                {
                    Console.WriteLine("Too high! Try again.");
                }

                if (attempts >= 10)
                {
                    Console.WriteLine("Sorry, you didn't guess the num. The num was " + randomNumber);
                    break;
                }

            } while (!win);

            if (win)
            {
                Console.WriteLine("Congratulations! You guessed the num correctly.");
            }
        }
    }

}

